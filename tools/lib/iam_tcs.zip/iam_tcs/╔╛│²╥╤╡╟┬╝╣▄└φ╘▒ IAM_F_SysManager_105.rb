#
# description:
# author:wuhongliang
# date:2016-07-25 10:00:17
# modify:
#
    testcase{
      attr = {"id"=>"IAM_F_SysManager_105", "level"=>"P2", "auto"=>"n"}
    def prepare

    end

    def process

      operate("1、ssh登录IAM服务器；") {
}

operate("2、登录超级管理员；") {
}

operate("3、删除该管理员") {
}

operate("4、重新登录该管理员；") {
}



    end

    def clearup
    operate("1.恢复默认设置"){

    }
    end

    }
